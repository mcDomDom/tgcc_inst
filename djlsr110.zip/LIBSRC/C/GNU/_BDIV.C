#define L_bdiv 
#include "gnulib2/gnulib2.c" 
