#define L_xordi3 
#include "gnulib2/gnulib2.c" 
