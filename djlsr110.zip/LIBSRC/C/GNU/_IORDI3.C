#define L_iordi3 
#include "gnulib2/gnulib2.c" 
