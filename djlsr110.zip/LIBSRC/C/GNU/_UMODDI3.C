#define L_umoddi3 
#include "gnulib2/gnulib2.c" 
