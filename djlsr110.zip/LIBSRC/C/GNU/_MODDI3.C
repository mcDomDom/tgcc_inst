#define L_moddi3 
#include "gnulib2/gnulib2.c" 
