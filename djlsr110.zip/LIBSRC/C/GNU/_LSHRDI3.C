#define L_lshrdi3 
#include "gnulib2/gnulib2.c" 
