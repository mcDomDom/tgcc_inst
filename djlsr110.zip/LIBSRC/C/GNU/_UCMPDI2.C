#define L_ucmpdi2 
#include "gnulib2/gnulib2.c" 
