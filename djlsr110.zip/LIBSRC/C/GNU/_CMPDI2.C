#define L_cmpdi2 
#include "gnulib2/gnulib2.c" 
