vfork()
{
  return -1;
}
