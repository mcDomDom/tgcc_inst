sigsetmask()
{
}

